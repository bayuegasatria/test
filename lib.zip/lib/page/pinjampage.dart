import 'package:flutter/material.dart';
import 'package:newapp/page/accpage.dart';
import 'package:newapp/page/dashboard.dart';
import 'package:newapp/page/user_provider.dart' show UserProvider;
import 'package:provider/provider.dart' show Provider;
import '../db/database_helper.dart';

class PinjamPage extends StatefulWidget {
  const PinjamPage({super.key});

  @override
  State<PinjamPage> createState() => _PinjamPageState();
}

class _PinjamPageState extends State<PinjamPage> {
  final TextEditingController nomorAjuanController = TextEditingController();
  final TextEditingController namaPengajuController = TextEditingController();
  final TextEditingController tujuanController = TextEditingController();
  final TextEditingController pengemudiController = TextEditingController();
  final TextEditingController jumlahPenumpangController =
      TextEditingController();
  final TextEditingController keteranganController = TextEditingController();

  DateTime dariTanggal = DateTime.now();
  TimeOfDay dariJam = const TimeOfDay(hour: 7, minute: 30);
  DateTime sampaiTanggal = DateTime.now().add(const Duration(days: 1));
  TimeOfDay sampaiJam = const TimeOfDay(hour: 10, minute: 0);

  String jenisKendaraan = "Mobil"; // default
  String supir = "Ya"; // default
  late String noPengajuan; // nomor pengajuan auto generate

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();

    // auto nomor pengajuan
    noPengajuan = "PGJ-${now.millisecondsSinceEpoch}";
    nomorAjuanController.text = noPengajuan;

    // default waktu
    dariTanggal = DateTime(now.year, now.month, now.day);
    dariJam = TimeOfDay(hour: now.hour, minute: now.minute);
    final satuJamSetelah = now.add(const Duration(hours: 1));
    sampaiTanggal = DateTime(
      satuJamSetelah.year,
      satuJamSetelah.month,
      satuJamSetelah.day,
    );
    sampaiJam = TimeOfDay(
      hour: satuJamSetelah.hour,
      minute: satuJamSetelah.minute,
    );

    // cek pinjaman aktif
    _cekPinjamanAktif();
  }

  /// 🔹 Cek apakah user masih punya pinjaman aktif
  Future<void> _cekPinjamanAktif() async {
    final user = Provider.of<UserProvider>(context, listen: false);
    final db = DatabaseHelper();
    final userId = int.parse(user.id);

    final existing = await db.getPinjamanAktifByUser(userId);
    debugPrint(
      "🔎 Cek pinjaman aktif userId=$userId -> ${existing.length} data",
    );

    if (existing.isNotEmpty && mounted) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => AlertDialog(
          title: const Text("Peminjaman Aktif"),
          content: const Text(
            "Anda masih mempunyai pinjaman yang belum selesai.",
          ),
          actions: [
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                minimumSize: const Size(150, 60),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              onPressed: () {
                Navigator.of(ctx).pop();
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => const Dashboard()),
                );
              },
              child: const Text(
                "OK",
                style: TextStyle(fontSize: 20, color: Colors.white),
              ),
            ),
          ],
        ),
      );
    }
  }

  /// Helper untuk format tanggal+jam jadi string
  String _toDateString(DateTime dt, TimeOfDay tod) {
    final jam = tod.hour.toString().padLeft(2, '0');
    final menit = tod.minute.toString().padLeft(2, '0');
    return "${dt.year.toString().padLeft(4, '0')}-"
        "${dt.month.toString().padLeft(2, '0')}-"
        "${dt.day.toString().padLeft(2, '0')} $jam:$menit:00";
  }

  /// 🔹 Pilih tanggal
  Future<void> pilihTanggal(BuildContext context, bool isDari) async {
    final DateTime now = DateTime.now();
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: isDari ? dariTanggal : sampaiTanggal,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );

    if (picked != null) {
      setState(() {
        if (isDari) {
          if (picked.isBefore(DateTime(now.year, now.month, now.day))) {
            dariTanggal = DateTime(now.year, now.month, now.day);
          } else {
            dariTanggal = picked;
          }

          if (sampaiTanggal.isBefore(dariTanggal)) {
            sampaiTanggal = dariTanggal;
          }

          if (sampaiTanggal.isAtSameMomentAs(dariTanggal)) {
            if (sampaiJam.hour < dariJam.hour ||
                (sampaiJam.hour == dariJam.hour &&
                    sampaiJam.minute <= dariJam.minute)) {
              sampaiJam = TimeOfDay(
                hour: (dariJam.hour + 1) % 24,
                minute: dariJam.minute,
              );
            }
          }
        } else {
          if (picked.isBefore(dariTanggal)) {
            sampaiTanggal = dariTanggal;
          } else {
            sampaiTanggal = picked;
          }

          if (sampaiTanggal.isAtSameMomentAs(dariTanggal)) {
            if (sampaiJam.hour < dariJam.hour ||
                (sampaiJam.hour == dariJam.hour &&
                    sampaiJam.minute <= dariJam.minute)) {
              sampaiJam = TimeOfDay(
                hour: (dariJam.hour + 1) % 24,
                minute: dariJam.minute,
              );
            }
          }
        }
      });
    }
  }

  /// 🔹 Pilih jam
  Future<void> pilihJam(BuildContext context, bool isDari) async {
    final DateTime now = DateTime.now();
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: isDari ? dariJam : sampaiJam,
      initialEntryMode: TimePickerEntryMode.input, // 🔹 langsung digital
      builder: (context, child) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: true),
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() {
        if (isDari) {
          if (dariTanggal.year == now.year &&
              dariTanggal.month == now.month &&
              dariTanggal.day == now.day) {
            if (picked.hour < now.hour ||
                (picked.hour == now.hour && picked.minute < now.minute)) {
              dariJam = TimeOfDay(hour: now.hour, minute: now.minute);
            } else {
              dariJam = picked;
            }
          } else {
            dariJam = picked;
          }

          if (dariTanggal.isAtSameMomentAs(sampaiTanggal)) {
            if (sampaiJam.hour < dariJam.hour ||
                (sampaiJam.hour == dariJam.hour &&
                    sampaiJam.minute <= dariJam.minute)) {
              sampaiJam = TimeOfDay(
                hour: (dariJam.hour + 1) % 24,
                minute: dariJam.minute,
              );
            }
          }
        } else {
          if (sampaiTanggal.isAtSameMomentAs(dariTanggal)) {
            if (picked.hour < dariJam.hour ||
                (picked.hour == dariJam.hour &&
                    picked.minute <= dariJam.minute)) {
              sampaiJam = TimeOfDay(
                hour: (dariJam.hour + 1) % 24,
                minute: dariJam.minute,
              );
            } else {
              sampaiJam = picked;
            }
          } else {
            sampaiJam = picked;
          }
        }
      });
    }
  }

  /// 🔹 Simpan ke DB
  Future<void> _simpanPengajuan(String userId) async {
    final start = DateTime(
      dariTanggal.year,
      dariTanggal.month,
      dariTanggal.day,
      dariJam.hour,
      dariJam.minute,
    );
    final end = DateTime(
      sampaiTanggal.year,
      sampaiTanggal.month,
      sampaiTanggal.day,
      sampaiJam.hour,
      sampaiJam.minute,
    );

    if (start.isAfter(end)) {
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text("Tanggal/Jam Tidak Valid"),
          content: const Text(
            "Waktu mulai tidak boleh melebihi waktu selesai.",
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text("OK"),
            ),
          ],
        ),
      );
      return;
    }

    final db = DatabaseHelper();
    await (await db.database).insert("pengajuan", {
      "id_user": int.tryParse(userId),
      "no_pengajuan": noPengajuan,
      "tujuan": tujuanController.text,
      "jenis_kendaraan": jenisKendaraan,
      "perlu_supir": supir.toLowerCase(),
      "pengemudi": pengemudiController.text,
      "tanggal_berangkat": _toDateString(dariTanggal, dariJam),
      "tanggal_kembali": _toDateString(sampaiTanggal, sampaiJam),
      "jumlah_pengguna": int.tryParse(jumlahPenumpangController.text) ?? 0,
      "keterangan": keteranganController.text,
      "status": "baru",
    });
  }

  @override
  Widget build(BuildContext context) {
    final user = Provider.of<UserProvider>(context);
    namaPengajuController.text = user.nama;

    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          toolbarHeight: 91,
          title: const Text(
            "Peminjaman Kendaraan",
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: const Color(0xFF1E88E5),
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(50),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: const BoxDecoration(
                color: Colors.white,
                border: Border(
                  top: BorderSide(color: Colors.blueGrey, width: 1),
                  bottom: BorderSide(color: Colors.blueGrey, width: 1),
                ),
              ),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const Dashboard(),
                        ),
                      );
                    },
                    icon: const Icon(Icons.arrow_back, color: Colors.black),
                  ),
                  const SizedBox(width: 10),
                  const Text(
                    "Detail Peminjaman",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                  ),
                ],
              ),
            ),
          ),
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Nomor Ajuan
              const Text(
                "Nomor Ajuan",
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 20),
              TextField(
                controller: nomorAjuanController,
                readOnly: true,
                decoration: const InputDecoration(
                  labelText: "Nomor Ajuan",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 20),

              // Nama Pengaju
              const Text(
                "Nama Pengaju",
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 20),
              TextField(
                controller: namaPengajuController,
                readOnly: true,
                decoration: const InputDecoration(
                  labelText: "Nama Pengaju",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 20),

              // Tanggal Pemakaian
              const Text(
                "Tanggal Pemakaian",
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: InkWell(
                      onTap: () => pilihTanggal(context, true),
                      child: InputDecorator(
                        decoration: const InputDecoration(
                          labelText: "Dari",
                          border: OutlineInputBorder(),
                        ),
                        child: Text(
                          "${dariTanggal.day}/${dariTanggal.month}/${dariTanggal.year}",
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: InkWell(
                      onTap: () => pilihJam(context, true),
                      child: InputDecorator(
                        decoration: const InputDecoration(
                          labelText: "Jam",
                          border: OutlineInputBorder(),
                        ),
                        child: Text(
                          "${dariJam.hour.toString().padLeft(2, '0')}:${dariJam.minute.toString().padLeft(2, '0')}",
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: InkWell(
                      onTap: () => pilihTanggal(context, false),
                      child: InputDecorator(
                        decoration: const InputDecoration(
                          labelText: "Sampai",
                          border: OutlineInputBorder(),
                        ),
                        child: Text(
                          "${sampaiTanggal.day}/${sampaiTanggal.month}/${sampaiTanggal.year}",
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: InkWell(
                      onTap: () => pilihJam(context, false),
                      child: InputDecorator(
                        decoration: const InputDecoration(
                          labelText: "Jam",
                          border: OutlineInputBorder(),
                        ),
                        child: Text(
                          "${sampaiJam.hour.toString().padLeft(2, '0')}:${sampaiJam.minute.toString().padLeft(2, '0')}",
                        ),
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 20),

              // Tujuan
              const Text(
                "Tujuan",
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 20),
              TextField(
                controller: tujuanController,
                decoration: const InputDecoration(
                  labelText: "Tujuan",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 20),

              // Jenis Kendaraan
              const Text(
                "Jenis Kendaraan",
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: RadioListTile(
                      title: const Text("Mobil"),
                      value: "Mobil",
                      groupValue: jenisKendaraan,
                      onChanged: (value) {
                        setState(() => jenisKendaraan = value.toString());
                      },
                    ),
                  ),
                  Expanded(
                    child: RadioListTile(
                      title: const Text("Motor"),
                      value: "Motor",
                      groupValue: jenisKendaraan,
                      onChanged: (value) {
                        setState(() => jenisKendaraan = value.toString());
                      },
                    ),
                  ),
                ],
              ),

              if (jenisKendaraan == "Mobil") ...[
                const SizedBox(height: 12),
                const Text(
                  "Supir",
                  style: TextStyle(fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: RadioListTile(
                        title: const Text("Ya"),
                        value: "Ya",
                        groupValue: supir,
                        onChanged: (value) {
                          setState(() => supir = value.toString());
                        },
                      ),
                    ),
                    Expanded(
                      child: RadioListTile(
                        title: const Text("Tidak"),
                        value: "Tidak",
                        groupValue: supir,
                        onChanged: (value) {
                          setState(() => supir = value.toString());
                        },
                      ),
                    ),
                  ],
                ),
              ],

              if ((jenisKendaraan == "Mobil" && supir == "Tidak") ||
                  jenisKendaraan == "Motor") ...[
                const SizedBox(height: 20),
                const Text(
                  "Pengemudi",
                  style: TextStyle(fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: pengemudiController,
                  decoration: const InputDecoration(
                    labelText: "Pengemudi",
                    border: OutlineInputBorder(),
                  ),
                ),
              ],

              const SizedBox(height: 20),

              const Text(
                "Jumlah Penumpang",
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: 150,
                child: TextField(
                  controller: jumlahPenumpangController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: "Jumlah Penumpang",
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              const SizedBox(height: 20),

              const Text(
                "Keterangan",
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 20),
              TextField(
                controller: keteranganController,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: "Keterangan",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 20),

              Center(
                child: SizedBox(
                  height: 70,
                  width: 200,
                  child: ElevatedButton(
                    onPressed: () async {
                      await _simpanPengajuan(user.id);
                      if (!mounted) return;
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const AccPage(),
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      elevation: 5,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 20,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      backgroundColor: Colors.green,
                    ),
                    child: const Text(
                      "Selesai",
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
