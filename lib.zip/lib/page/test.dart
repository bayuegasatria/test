import 'package:flutter/material.dart';
import '../db/database_helper.dart';

class TestPinjamPage extends StatefulWidget {
  const TestPinjamPage({Key? key}) : super(key: key);

  @override
  State<TestPinjamPage> createState() => _PinjamPageState();
}

class _PinjamPageState extends State<TestPinjamPage> {
  late Future<List<Map<String, dynamic>>> _pinjamList;

  @override
  void initState() {
    super.initState();
    _loadPinjam();
  }

  void _loadPinjam() {
    _pinjamList = _getPinjam();
  }

  Future<List<Map<String, dynamic>>> _getPinjam() async {
    final db = await DatabaseHelper().database;
    return await db.query("pinjam");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Data Pinjam")),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: _pinjamList,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text("Belum ada data pinjam"));
          }

          final data = snapshot.data!;
          return ListView.builder(
            itemCount: data.length,
            itemBuilder: (context, index) {
              final row = data[index];
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                child: ListTile(
                  title: Text("ID Pengajuan: ${row['id_pengajuan']}"),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Tgl Berangkat: ${row['tanggal_berangkat']}"),
                      Text("Harus Kembali: ${row['tanggal_harus_kembali']}"),
                      Text("Kembali: ${row['tanggal_kembali'] ?? '-'}"),
                      Text("Kendaraan ID: ${row['id_kendaraan']}"),
                      Text("Supir ID: ${row['id_supir'] ?? '-'}"),
                      Text("Status: ${row['status']}"),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
