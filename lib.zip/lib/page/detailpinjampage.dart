import 'package:flutter/material.dart';
import 'package:newapp/page/historypinjampage.dart';
import 'package:sticky_headers/sticky_headers/widget.dart';

class Detailpinjampage extends StatefulWidget {
  final Map<String, dynamic>? data; // 👉 ambil data dari history

  const Detailpinjampage({super.key, this.data});

  @override
  State<Detailpinjampage> createState() => _DetailpinjampageState();
}

class _DetailpinjampageState extends State<Detailpinjampage> {
  // Dummy data fallback
  final Map<String, String> dummyData = {
    "no_pengajuan": "031/PKB/BBPOM/09/2025",
    "nama": "Marina Rizka , SKM",
    "batas_pengembalian": "28 September 2025 - 17:00",
    "tujuan": "Banjarmasin",
    "kendaraan": "Toyota Avanza - B 1234 CD",
    "status": "sedang dipinjam", // bisa "selesai" atau "terlambat"
  };

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case "selesai":
        return Colors.green;
      case "terlambat":
        return Colors.red;
      default:
        return Colors.orange; // sedang dipinjam
    }
  }

  IconData _getStatusIcon(String status) {
    switch (status.toLowerCase()) {
      case "selesai":
        return Icons.check_circle;
      case "terlambat":
        return Icons.cancel;
      default:
        return Icons.access_time;
    }
  }

  String _getStatusLabel(String status) {
    switch (status.toLowerCase()) {
      case "selesai":
        return "Selesai";
      case "terlambat":
        return "Terlambat";
      default:
        return "Sedang Dipinjam";
    }
  }

  @override
  Widget build(BuildContext context) {
    // Ambil data dari widget.data kalau ada, kalau tidak pakai dummy
    final Map<String, dynamic> data = widget.data ?? dummyData;

    final String status = data["status"] ?? dummyData["status"]!;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        toolbarHeight: 80,
        title: const Text(
          "Detail Pengembalian",
          style: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: const Color(0xFF1E88E5),
      ),
      body: SingleChildScrollView(
        child: StickyHeader(
          header: Container(
            decoration: const BoxDecoration(
              color: Colors.white,
              border: Border(
                bottom: BorderSide(color: Colors.blueGrey, width: 1),
              ),
            ),
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                IconButton(
                  onPressed: () => Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const HistoryPinjamPage(),
                    ),
                  ),
                  icon: const Icon(Icons.arrow_back, color: Colors.black),
                ),
                const SizedBox(width: 20),
                const Text(
                  "Detail Peminjaman",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                ),
              ],
            ),
          ),
          content: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Badge Status
                Align(
                  alignment: Alignment.centerLeft,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 30,
                      vertical: 12,
                    ),
                    decoration: BoxDecoration(
                      color: _getStatusColor(status),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          _getStatusIcon(status),
                          color: Colors.white,
                          size: 22,
                        ),
                        const SizedBox(width: 10),
                        Text(
                          _getStatusLabel(status),
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                // No Pengajuan
                const Text(
                  "No Pengajuan",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                ),
                const SizedBox(height: 10),
                TextField(
                  readOnly: true,
                  controller: TextEditingController(text: data["no_pengajuan"]),
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 20),

                // Nama Peminjam
                const Text(
                  "Nama Peminjam",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                ),
                const SizedBox(height: 10),
                TextField(
                  readOnly: true,
                  controller: TextEditingController(text: data["nama"]),
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 20),

                // Batas Waktu Pengembalian
                const Text(
                  "Batas Waktu Pengembalian",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                ),
                const SizedBox(height: 10),
                TextField(
                  readOnly: true,
                  controller: TextEditingController(
                    text: data["batas_pengembalian"],
                  ),
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 20),

                // Tujuan
                const Text(
                  "Tujuan",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                ),
                const SizedBox(height: 10),
                TextField(
                  readOnly: true,
                  controller: TextEditingController(text: data["tujuan"]),
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 20),

                // Nama Kendaraan
                const Text(
                  "Nama Kendaraan",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                ),
                const SizedBox(height: 10),
                TextField(
                  readOnly: true,
                  controller: TextEditingController(text: data["kendaraan"]),
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
