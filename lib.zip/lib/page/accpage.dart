import 'package:flutter/material.dart';
import 'package:newapp/page/accdetailpage.dart';
import 'package:newapp/page/dashboard.dart';
import 'package:newapp/page/user_provider.dart';
import 'package:provider/provider.dart';
import '../db/database_helper.dart';

class AccPage extends StatefulWidget {
  const AccPage({super.key});

  @override
  State<AccPage> createState() => _AccPageState();
}

class _AccPageState extends State<AccPage> {
  String searchQuery = "";
  final TextEditingController _searchController = TextEditingController();

  Future<List<Map<String, dynamic>>>? _accFuture;

  /// Ambil data dari database (fetch sekali)
  Future<List<Map<String, dynamic>>> _fetchData(String role, int userId) async {
    final db = DatabaseHelper();
    return await db.getAccData(role: role, userId: userId);
  }

  /// Icon status
  Icon getStatusIcon(String status) {
    switch (status) {
      case "disetujui":
        return const Icon(Icons.check_circle, color: Colors.green, size: 40);
      case "ditolak":
        return const Icon(Icons.cancel, color: Colors.red, size: 40);
      default:
        return const Icon(Icons.access_time, color: Colors.orange, size: 40);
    }
  }

  void _onSearchSubmit(String value) {
    setState(() {
      searchQuery = value;
    });
  }

  @override
  void initState() {
    super.initState();
    final user = Provider.of<UserProvider>(context, listen: false);
    final int currentUserId = int.parse(user.id);
    final String role = user.role;

    // simpan future hanya sekali
    _accFuture = _fetchData(role, currentUserId);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          toolbarHeight: 91,
          title: const Text(
            "Persetujuan Peminjaman",
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: const Color(0xFF1E88E5),
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(120),
            child: Column(
              children: [
                Container(
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    border: Border(
                      bottom: BorderSide(color: Colors.blueGrey, width: 1),
                    ),
                  ),
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    children: [
                      IconButton(
                        onPressed: () {
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const Dashboard(),
                            ),
                          );
                        },
                        icon: const Icon(Icons.arrow_back, color: Colors.black),
                      ),
                      const SizedBox(width: 20),
                      const Text(
                        "List Peminjaman",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  color: Colors.white,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                  child: TextField(
                    controller: _searchController,
                    onSubmitted: _onSearchSubmit,
                    decoration: InputDecoration(
                      prefixIcon: const Icon(Icons.search),
                      hintText: "Ketik lalu tekan Enter...",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 0,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        body: FutureBuilder<List<Map<String, dynamic>>>(
          future: _accFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: CircularProgressIndicator(),
                ),
              );
            }
            if (snapshot.hasError) {
              return Center(child: Text("Error: ${snapshot.error}"));
            }

            final data = snapshot.data ?? [];
            if (data.isEmpty) {
              return const Center(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Text("Tidak ada data pengajuan"),
                ),
              );
            }

            final filteredData = data.where((item) {
              return item["no_pengajuan"].toString().toLowerCase().contains(
                    searchQuery.toLowerCase(),
                  ) ||
                  item["nama"].toString().toLowerCase().contains(
                    searchQuery.toLowerCase(),
                  ) ||
                  item["tujuan"].toString().toLowerCase().contains(
                    searchQuery.toLowerCase(),
                  );
            }).toList();

            return ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: filteredData.length,
              itemBuilder: (context, index) {
                final item = filteredData[index];
                return Card(
                  color: Colors.white,
                  margin: const EdgeInsets.symmetric(vertical: 6),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(12),
                    leading: getStatusIcon(item["status"] ?? "pending"),
                    title: Text(
                      item["no_pengajuan"] ?? "-",
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(item["nama"] ?? ""),
                        const SizedBox(height: 6),
                        Row(
                          children: [
                            const Icon(
                              Icons.calendar_today,
                              size: 16,
                              color: Colors.grey,
                            ),
                            const SizedBox(width: 4),
                            Text(item["tanggal_berangkat"] ?? ""),
                            const SizedBox(width: 10),
                            const Icon(
                              Icons.location_on,
                              size: 16,
                              color: Colors.grey,
                            ),
                            const SizedBox(width: 4),
                            Text(item["tujuan"] ?? ""),
                          ],
                        ),
                      ],
                    ),
                    onTap: () async {
                      final db = DatabaseHelper();
                      final detail = await db.getPengajuanById(item["id"]);

                      if (detail != null && context.mounted) {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => AccDetailPage(
                              data: detail,
                              status: detail["status"] ?? "pending",
                            ),
                          ),
                        );
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text("Data tidak ditemukan")),
                        );
                      }
                    },
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
