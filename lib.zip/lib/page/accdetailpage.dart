import 'package:flutter/material.dart';
import 'package:newapp/page/accpage.dart';
import 'package:newapp/page/user_provider.dart';
import 'package:provider/provider.dart';
import '../db/database_helper.dart';

class AccDetailPage extends StatefulWidget {
  final Map<String, dynamic> data;
  final String status;

  const AccDetailPage({super.key, required this.data, required this.status});

  @override
  State<AccDetailPage> createState() => _AccDetailPageState();
}

class _AccDetailPageState extends State<AccDetailPage> {
  String? selectedKendaraan;
  String? selectedSupir;
  final TextEditingController catatanController = TextEditingController();

  List<Map<String, dynamic>> kendaraanList = [];
  List<Map<String, dynamic>> supirList = [];
  Map<String, dynamic>? detailAcc;

  final db = DatabaseHelper();

  @override
  void initState() {
    super.initState();
    _loadDropdownData();
    if (widget.status.toLowerCase() == "disetujui") {
      _loadDetailAcc();
    }
  }

  Future<void> _loadDropdownData() async {
    final tglBerangkat = DateTime.parse(widget.data["tanggal_berangkat"]);
    final tglKembali = DateTime.parse(widget.data["tanggal_kembali"]);

    final mobil = await db.getAvailableMobil(tglBerangkat, tglKembali);
    final supir = await db.getAvailableSupir(tglBerangkat, tglKembali);

    setState(() {
      kendaraanList = mobil;
      supirList = supir;
    });
  }

  Future<void> _loadDetailAcc() async {
    final res = await db.getDetailAcc(widget.data["id"]);
    if (res.isNotEmpty) {
      setState(() {
        detailAcc = res.first;
      });
    }
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case "disetujui":
        return Colors.green;
      case "ditolak":
        return Colors.red;
      default:
        return Colors.orange; // pending
    }
  }

  Future<void> _handleTolak() async {
    await db.tolakPengajuan(widget.data["id"], catatanController.text);
    if (mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Pengajuan ditolak")));
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const AccPage()),
      );
    }
  }

  Future<void> _handleAcc() async {
    if (selectedKendaraan == null || selectedSupir == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Pilih kendaraan dan supir terlebih dahulu"),
        ),
      );
      return;
    }

    final idMobil = int.parse(selectedKendaraan!);
    final idSupir = int.parse(selectedSupir!);

    await db.accPengajuan(
      pengajuan: widget.data,
      idMobil: idMobil,
      idSupir: idSupir,
      catatan: catatanController.text,
    );

    if (mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Pengajuan disetujui")));
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const AccPage()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = Provider.of<UserProvider>(context);
    final bool isAtasan = user.role == "atasan";
    final bool isFinal = [
      "disetujui",
      "ditolak",
    ].contains(widget.status.toLowerCase());

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        toolbarHeight: 91,
        title: const Text(
          "Detail Persetujuan",
          style: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: const Color(0xFF1E88E5),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(60),
          child: Container(
            decoration: const BoxDecoration(
              color: Colors.white,
              border: Border(
                bottom: BorderSide(color: Colors.blueGrey, width: 1),
              ),
            ),
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                IconButton(
                  onPressed: () {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (context) => const AccPage()),
                    );
                  },
                  icon: const Icon(Icons.arrow_back, color: Colors.black),
                ),
                const SizedBox(width: 20),
                const Text(
                  "Detail Peminjaman",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                ),
              ],
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Badge Status
            Align(
              alignment: Alignment.centerLeft,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 10,
                ),
                decoration: BoxDecoration(
                  color: _getStatusColor(widget.status).withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      widget.status.toLowerCase() == "disetujui"
                          ? Icons.check_circle
                          : widget.status.toLowerCase() == "ditolak"
                          ? Icons.cancel
                          : Icons.access_time,
                      color: _getStatusColor(widget.status),
                      size: 22,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      widget.status.toLowerCase() == "disetujui"
                          ? "Disetujui"
                          : widget.status.toLowerCase() == "ditolak"
                          ? "Ditolak"
                          : "Menunggu",
                      style: TextStyle(
                        color: _getStatusColor(widget.status),
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 20),

            _buildReadOnlyField(
              "Nomor Surat",
              widget.data["no_pengajuan"] ?? "-",
            ),
            _buildReadOnlyField("Nama Pengaju", widget.data["nama"] ?? "-"),
            _buildReadOnlyField("Tujuan", widget.data["tujuan"] ?? "-"),
            _buildReadOnlyField(
              "Tanggal Berangkat",
              widget.data["tanggal_berangkat"] ?? "-",
            ),
            _buildReadOnlyField(
              "Tanggal Kembali",
              widget.data["tanggal_kembali"] ?? "-",
            ),

            const SizedBox(height: 20),

            // === Kendaraan & Supir ===
            if (widget.status.toLowerCase() == "disetujui" &&
                detailAcc != null) ...[
              _buildReadOnlyField(
                "Kendaraan",
                detailAcc!["nama_kendaraan"] ?? "-",
              ),
              _buildReadOnlyField("Supir", detailAcc!["nama_supir"] ?? "-"),
            ] else if (widget.status.toLowerCase() != "ditolak") ...[
              const Text(
                "Pilih Kendaraan",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                decoration: const InputDecoration(border: OutlineInputBorder()),
                value: selectedKendaraan,
                items: kendaraanList.map((m) {
                  return DropdownMenuItem(
                    value: m["id"].toString(),
                    child: Text("${m["merk"]} (${m["da"]})"),
                  );
                }).toList(),
                onChanged: (!isFinal && isAtasan)
                    ? (val) => setState(() => selectedKendaraan = val)
                    : null,
              ),
              const SizedBox(height: 20),
              const Text(
                "Pilih Supir",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                decoration: const InputDecoration(border: OutlineInputBorder()),
                value: selectedSupir,
                items: supirList.map((s) {
                  return DropdownMenuItem(
                    value: s["id"].toString(),
                    child: Text("${s["nama"]} - ${s["nip"]}"),
                  );
                }).toList(),
                onChanged: (!isFinal && isAtasan)
                    ? (val) => setState(() => selectedSupir = val)
                    : null,
              ),
            ],

            const SizedBox(height: 20),

            if (widget.status.toLowerCase() == "disetujui" &&
                detailAcc != null) ...[
              _buildReadOnlyField("Catatan", detailAcc!["catatan"] ?? "-"),
            ] else if (widget.status.toLowerCase() != "ditolak") ...[
              const Text(
                "Catatan",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: catatanController,
                maxLines: 3,
                readOnly: !isAtasan || isFinal,
                decoration: const InputDecoration(border: OutlineInputBorder()),
              ),
            ],

            const SizedBox(height: 30),
            if (isAtasan && !isFinal)
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                    onPressed: _handleTolak,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      minimumSize: const Size(150, 60),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text(
                      "Tolak",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  ElevatedButton(
                    onPressed: _handleAcc,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      minimumSize: const Size(150, 60),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text(
                      "ACC",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildReadOnlyField(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
          ),
          const SizedBox(height: 10),
          TextField(
            readOnly: true,
            controller: TextEditingController(text: value),
            decoration: const InputDecoration(border: OutlineInputBorder()),
          ),
        ],
      ),
    );
  }
}
