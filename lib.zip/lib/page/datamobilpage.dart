import 'package:flutter/material.dart';
import 'package:newapp/page/dashboard.dart';
import '../db/database_helper.dart';

class DataMobilPage extends StatefulWidget {
  const DataMobilPage({super.key});

  @override
  State<DataMobilPage> createState() => _DataMobilPageState();
}

class _DataMobilPageState extends State<DataMobilPage> {
  String searchQuery = "";
  final TextEditingController _searchController = TextEditingController();

  Future<List<Map<String, dynamic>>>? _mobilFuture;

  @override
  void initState() {
    super.initState();
    // fetch data sekali saja
    _mobilFuture = DatabaseHelper().getMobilWithStatus();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _onSearchSubmit(String value) {
    setState(() {
      searchQuery = value;
    });
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          toolbarHeight: 91,
          automaticallyImplyLeading: false,
          title: const Text(
            "Data Kendaraan",
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: const Color(0xFF1E88E5),
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(120),
            child: Column(
              children: [
                // header bawah AppBar
                Container(
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    border: Border(
                      bottom: BorderSide(color: Colors.blueGrey, width: 1),
                    ),
                  ),
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    children: [
                      IconButton(
                        onPressed: () {
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const Dashboard(),
                            ),
                          );
                        },
                        icon: const Icon(Icons.arrow_back, color: Colors.black),
                      ),
                      const SizedBox(width: 20),
                      const Text(
                        "List Kendaraan",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                    ],
                  ),
                ),
                // Search bar
                Container(
                  color: Colors.white,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                  child: TextField(
                    controller: _searchController,
                    onSubmitted: _onSearchSubmit,
                    decoration: InputDecoration(
                      prefixIcon: const Icon(Icons.search),
                      hintText: "Ketik lalu tekan Enter...",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 0,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        body: FutureBuilder<List<Map<String, dynamic>>>(
          future: _mobilFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return const Center(child: Text("Tidak ada data kendaraan"));
            }

            final kendaraanList = snapshot.data!;
            final filteredKendaraan = kendaraanList.where((kendaraan) {
              return kendaraan["merk"].toString().toLowerCase().contains(
                    searchQuery.toLowerCase(),
                  ) ||
                  kendaraan["nomor_inventaris"]
                      .toString()
                      .toLowerCase()
                      .contains(searchQuery.toLowerCase());
            }).toList();

            return ListView.builder(
              padding: const EdgeInsets.only(bottom: 12),
              itemCount: filteredKendaraan.length,
              itemBuilder: (context, index) {
                final kendaraan = filteredKendaraan[index];
                final status = kendaraan["status"] ?? "";

                Color cardColor;
                switch (status) {
                  case "Ready":
                    cardColor = Colors.green.shade100;
                    break;
                  case "Dipakai":
                    cardColor = Colors.orange.shade100;
                    break;
                  default:
                    cardColor = Colors.grey.shade200;
                }

                return Card(
                  color: cardColor,
                  margin: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 6,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: ListTile(
                    leading: const Icon(
                      Icons.directions_car,
                      size: 40,
                      color: Colors.blueGrey,
                    ),
                    title: Text(
                      kendaraan["merk"] ?? "-",
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "No. Inventaris: ${kendaraan["nomor_inventaris"] ?? '-'}",
                        ),
                        Text("DA: ${kendaraan["da"] ?? '-'}"),
                        Text("Status: $status"),
                        if (status == "Dipakai")
                          Text(
                            "Dari: ${kendaraan["tanggal_berangkat"] ?? '-'}\n"
                            "Sampai: ${kendaraan["tanggal_kembali"] ?? '-'}",
                          ),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
