import 'package:flutter/material.dart';

class UserProvider with ChangeNotifier {
  String _role = "atasan"; // default role
  String _nama = "Bayu Ega Satria";
  String _nip = "2210010249";
  String _id = "1";

  String get role => _role;
  String get nama => _nama;
  String get nip => _nip;
  String get id => _id;

  void setRole(String newRole) {
    _role = newRole;
    notifyListeners(); // update semua widget yang listen
  }

  void setUserData(String nama, String nip, String role, String id) {
    _nama = nama;
    _nip = nip;
    _role = role;
    _id = id;
    notifyListeners();
  }
}
