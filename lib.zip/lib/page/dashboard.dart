import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:newapp/page/accpage.dart';
import '../page/accdetailpage.dart';
import 'package:newapp/page/datamobilpage.dart';
import 'package:newapp/page/historypinjampage.dart';
import 'package:newapp/page/loginpage.dart';
import 'package:newapp/page/pengembalianpage.dart';
import 'package:newapp/page/pinjampage.dart';
import 'package:newapp/page/user_provider.dart' show UserProvider;
import 'package:provider/provider.dart';
import 'package:sticky_headers/sticky_headers/widget.dart';
import '../db/database_helper.dart';
import '../page/test.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> with WidgetsBindingObserver {
  final dbHelper = DatabaseHelper();

  late Future<List<Map<String, dynamic>>> statusFuture;
  late Future<List<Map<String, dynamic>>> jadwalFuture;
  late Future<List<Map<String, dynamic>>> notifFuture;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadData();
  }

  void _loadData() {
    final user = Provider.of<UserProvider>(context, listen: false);
    final now = DateTime.now();

    setState(() {
      statusFuture = dbHelper.getStatusPinjamUser(int.parse(user.id), now);
      jadwalFuture = dbHelper.getJadwalMobil(now);
      notifFuture = dbHelper.getNotifikasi(
        role: user.role,
        userId: int.parse(user.id),
      );
    });
  }

  /// 🔹 Lifecycle listener
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      // halaman kembali aktif → refresh otomatis
      _loadData();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final user = Provider.of<UserProvider>(context);
    final dateFormat = DateFormat("dd MMM yyyy, HH:mm");

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        toolbarHeight: 91,
        backgroundColor: const Color(0xFF1E88E5),
        leading: IconButton(
          onPressed: () {
            showAccountPanel(context);
          },
          icon: const CircleAvatar(
            radius: 18,
            backgroundColor: Colors.white,
            child: Icon(Icons.person, color: Color(0xFF1E88E5)),
          ),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              user.nama,
              style: const TextStyle(
                fontSize: 20,
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 5),
            Text(
              user.nip,
              style: const TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ],
        ),
        actions: [
          FutureBuilder<int>(
            future: () {
              final user = Provider.of<UserProvider>(context, listen: false);
              if (user.role == "atasan") {
                return DatabaseHelper().getNotifCount(status: "baru");
              } else {
                return DatabaseHelper().getNotifCountMultiple(
                  statuses: ["disetujui", "ditolak"],
                  userId: int.parse(user.id),
                );
              }
            }(),
            builder: (context, snapshot) {
              final notifCount = snapshot.data ?? 0;

              return IconButton(
                onPressed: () {
                  showNotificationPanel(context, notifFuture);
                },
                icon: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    const CircleAvatar(
                      radius: 18,
                      backgroundColor: Color(0xFF1E88E5),
                      child: Icon(Icons.notifications, color: Colors.white),
                    ),
                    if (notifCount > 0)
                      Positioned(
                        right: -2,
                        top: -2,
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: const BoxDecoration(
                            color: Colors.red,
                            shape: BoxShape.circle,
                          ),
                          constraints: const BoxConstraints(
                            minWidth: 18,
                            minHeight: 18,
                          ),
                          child: Text(
                            notifCount.toString(),
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ),
                  ],
                ),
              );
            },
          ),
          const SizedBox(width: 20),
        ],
      ),
      body: ListView(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ===== GRID MENU =====
              Container(
                decoration: BoxDecoration(
                  color: const Color(0xFF1E88E5),
                  borderRadius: const BorderRadius.vertical(
                    bottom: Radius.elliptical(200, 60),
                  ),
                ),
                child: Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.blueGrey, width: 1),
                    color: Colors.white,
                    borderRadius: const BorderRadius.all(Radius.circular(10)),
                  ),
                  margin: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 0,
                  ),
                  child: GridView.count(
                    crossAxisCount: 4,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    childAspectRatio: 0.8,
                    children: [
                      _buildMenuItem(
                        context,
                        iconPath: 'assets/icons/car-key.png',
                        title: "Peminjaman \nKendaraan",
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const PinjamPage(),
                            ),
                          );
                        },
                      ),
                      _buildMenuItem(
                        context,
                        iconPath: 'assets/icons/approved.png',
                        title: "Persetujuan \nPeminjaman",
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const AccPage(),
                            ),
                          );
                        },
                      ),
                      _buildMenuItem(
                        context,
                        iconPath: 'assets/icons/car.png',
                        title: "Data \nMobil",
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const DataMobilPage(),
                            ),
                          );
                        },
                      ),
                      _buildMenuItem(
                        context,
                        iconPath: 'assets/icons/history.png',
                        title: "History \nPeminjaman",
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const HistoryPinjamPage(),
                            ),
                          );
                        },
                      ),
                      _buildMenuItem(
                        context,
                        iconPath: 'assets/icons/optimizing.png',
                        title: "Pemeliharaan \nNon TIK",
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const TestPinjamPage(),
                            ),
                          );
                        },
                      ),
                      _buildMenuItem(
                        context,
                        iconPath: 'assets/icons/technical-support.png',
                        title: "Pemeliharaan \nTIK",
                      ),
                      _buildMenuItem(
                        context,
                        iconPath: 'assets/icons/report.png',
                        title: "Laporan",
                      ),
                      _buildMenuItem(
                        context,
                        iconPath: 'assets/icons/replacement.png',
                        title: "Pemindahan \nBarang",
                      ),
                    ],
                  ),
                ),
              ),

              // ===== CARD STATUS (from DB) =====
              FutureBuilder<List<Map<String, dynamic>>>(
                future: statusFuture,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Padding(
                      padding: EdgeInsets.all(20),
                      child: CircularProgressIndicator(),
                    );
                  }
                  if (!snapshot.hasData || snapshot.data!.isEmpty) {
                    return const SizedBox.shrink();
                  }

                  final item = snapshot.data!.first;
                  final tglMulai = DateTime.tryParse(item['tanggal_berangkat']);
                  final tglSelesai = DateTime.tryParse(item['tanggal_kembali']);
                  final now = DateTime.now();

                  return Padding(
                    padding: const EdgeInsets.only(left: 1, right: 1),
                    child: Card(
                      elevation: 2,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                        side: const BorderSide(
                          color: Colors.blueGrey,
                          width: 1,
                        ),
                      ),
                      color: Colors.white,
                      margin: const EdgeInsets.all(20),
                      child: ListTile(
                        leading: () {
                          if (tglMulai != null && tglMulai.isAfter(now)) {
                            return const Icon(
                              Icons.check_circle,
                              color: Colors.green,
                              size: 35,
                            );
                          } else if (tglMulai != null &&
                              tglSelesai != null &&
                              (now.isAfter(tglMulai) ||
                                  now.isAtSameMomentAs(tglMulai)) &&
                              now.isBefore(tglSelesai)) {
                            return Image.asset(
                              'assets/icons/hourglass.png',
                              width: 35,
                              height: 35,
                            );
                          } else {
                            return const Icon(
                              Icons.warning,
                              color: Colors.red,
                              size: 35,
                            );
                          }
                        }(),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => PengembalianPage(
                                data: {"id_pinjam": item['id']},
                              ),
                            ),
                          );
                        },
                        title: Text(
                          () {
                            if (tglMulai != null && tglMulai.isAfter(now)) {
                              return "Peminjaman Disetujui";
                            } else if (tglMulai != null &&
                                tglSelesai != null &&
                                (now.isAfter(tglMulai) ||
                                    now.isAtSameMomentAs(tglMulai)) &&
                                now.isBefore(tglSelesai)) {
                              return "Anda Sedang Memakai";
                            } else {
                              return "Peminjaman Terlambat";
                            }
                          }(),
                          style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 10),
                            Text("${item['nama_mobil']}  "),
                            Text(
                              "${tglMulai != null ? dateFormat.format(tglMulai) : ''} - ${tglSelesai != null ? dateFormat.format(tglSelesai) : ''}",
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),

              // ===== JADWAL MOBIL =====
              StickyHeader(
                header: Center(
                  child: Container(
                    color: Colors.white,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 12,
                    ),
                    child: const Text(
                      "Jadwal Mobil",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                        fontFamily: 'Roboto',
                      ),
                    ),
                  ),
                ),
                content: Center(
                  child: FutureBuilder<List<Map<String, dynamic>>>(
                    future: jadwalFuture,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const Padding(
                          padding: EdgeInsets.all(20),
                          child: CircularProgressIndicator(),
                        );
                      }
                      if (!snapshot.hasData || snapshot.data!.isEmpty) {
                        return const Padding(
                          padding: EdgeInsets.all(20),
                          child: Text("Tidak ada jadwal mobil."),
                        );
                      }

                      final data = snapshot.data!;
                      return Column(
                        children: data.map((item) {
                          final tgl = DateTime.tryParse(
                            item['tanggal_berangkat'],
                          );
                          return Card(
                            color: Colors.white,
                            margin: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 6,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                              side: const BorderSide(
                                color: Colors.blueGrey,
                                width: 1,
                              ),
                            ),
                            child: ListTile(
                              leading: Image.asset(
                                'assets/icons/car.png',
                                width: 35,
                                height: 35,
                              ),
                              title: Text(item['nama_mobil'] ?? "-"),
                              subtitle: Text(
                                "Dipinjam oleh: ${item['nama_user'] ?? '-'}\n${tgl != null ? dateFormat.format(tgl) : ''}",
                              ),
                              trailing: const Icon(
                                Icons.arrow_forward_ios,
                                size: 16,
                                color: Colors.grey,
                              ),
                              onTap: () {},
                            ),
                          );
                        }).toList(),
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// ===== Widget Item Menu Adaptif =====
Widget _buildMenuItem(
  BuildContext context, {
  required String iconPath,
  required String title,
  VoidCallback? onTap,
}) {
  final screenWidth = MediaQuery.of(context).size.width;

  return InkWell(
    onTap: onTap,
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Flexible(
          child: Image.asset(
            iconPath,
            width: screenWidth * 0.12,
            height: screenWidth * 0.12,
            fit: BoxFit.contain,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          title,
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: screenWidth * 0.03),
        ),
      ],
    ),
  );
}

/// ===== Notification Panel =====
void showNotificationPanel(
  BuildContext context,
  Future<List<Map<String, dynamic>>> notifFuture,
) {
  showGeneralDialog(
    context: context,
    barrierDismissible: true,
    barrierLabel: "Tutup",
    barrierColor: Colors.black54,
    transitionDuration: const Duration(milliseconds: 400),
    pageBuilder: (context, anim1, anim2) {
      return Align(
        alignment: Alignment.centerRight,
        child: Container(
          width: MediaQuery.of(context).size.width * 0.8,
          height: double.infinity,
          color: Colors.white,
          child: SafeArea(child: NotificationList(futureNotif: notifFuture)),
        ),
      );
    },
    transitionBuilder: slideFromRightTransition,
  );
}

class NotificationList extends StatefulWidget {
  final Future<List<Map<String, dynamic>>> futureNotif;
  const NotificationList({super.key, required this.futureNotif});

  @override
  State<NotificationList> createState() => _NotificationListState();
}

class _NotificationListState extends State<NotificationList> {
  List<int> dismissedIds = [];

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case "disetujui":
        return Colors.green;
      case "ditolak":
        return Colors.red;
      default:
        return Colors.orange; // baru / pending
    }
  }

  IconData _getStatusIcon(String status) {
    switch (status.toLowerCase()) {
      case "disetujui":
        return Icons.check_circle;
      case "ditolak":
        return Icons.cancel;
      default:
        return Icons.access_time;
    }
  }

  String _getTitleText(String status) {
    switch (status.toLowerCase()) {
      case "disetujui":
        return "Pengajuan anda disetujui";
      case "ditolak":
        return "Pengajuan anda ditolak";
      default:
        return "Ada pengajuan baru";
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = Provider.of<UserProvider>(context, listen: false);

    return FutureBuilder<List<Map<String, dynamic>>>(
      future: widget.futureNotif,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        List<Map<String, dynamic>> data = snapshot.data ?? [];

        // bagian build -> filter
        if (user.role == "atasan") {
          data = data
              .where((e) => (e["status"] ?? "").toLowerCase() == "baru")
              .toList();
        } else {
          data = data
              .where(
                (e) => [
                  "disetujui",
                  "ditolak",
                ].contains((e["status"] ?? "").toLowerCase()),
              )
              .where((e) => !dismissedIds.contains(e["id"]))
              .toList();
        }

        final hasNotif = data.isNotEmpty;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header dengan badge
            Container(
              padding: const EdgeInsets.all(16),
              decoration: const BoxDecoration(
                border: Border(
                  bottom: BorderSide(color: Colors.grey, width: 1),
                ),
              ),
              child: Row(
                children: [
                  Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Icon(
                        hasNotif
                            ? Icons.notifications_active
                            : Icons.notifications_none,
                        color: hasNotif ? Colors.blue : Colors.grey,
                        size: 28,
                      ),
                      if (hasNotif)
                        Positioned(
                          right: -2,
                          top: -2,
                          child: Container(
                            padding: const EdgeInsets.all(4),
                            decoration: const BoxDecoration(
                              color: Colors.red,
                              shape: BoxShape.circle,
                            ),
                            child: Text(
                              "${data.length}",
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(width: 10),
                  const Text(
                    "Notifikasi",
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                      decoration: TextDecoration.none,
                      fontFamily: 'Roboto',
                    ),
                  ),
                ],
              ),
            ),

            Expanded(
              child: hasNotif
                  ? ListView.builder(
                      itemCount: data.length,
                      itemBuilder: (context, index) {
                        final item = data[index];
                        final status = item["status"] ?? "baru";
                        return Card(
                          color: Colors.white,
                          margin: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: ListTile(
                            leading: Icon(
                              _getStatusIcon(status),
                              color: _getStatusColor(status),
                              size: 28,
                            ),
                            title: Text(
                              _getTitleText(status),
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                              maxLines: 1, // 🔹 hanya 1 baris
                              overflow: TextOverflow
                                  .ellipsis, // 🔹 jika panjang → "..."
                            ),
                            subtitle: Text(
                              "No. Pengajuan: ${item['no_pengajuan']}\nTujuan: ${item['tujuan']}",
                              maxLines: 2, // 🔹 batasi maksimal 2 baris
                              overflow: TextOverflow
                                  .ellipsis, // 🔹 jika panjang → "..."
                            ),
                            onTap: () async {
                              final db = DatabaseHelper();
                              final detail = await db.getPengajuanById(
                                item["id"],
                              );
                              if (detail != null && context.mounted) {
                                // update dibaca -> 1
                                await db.markNotifAsRead(item["id"]);

                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => AccDetailPage(
                                      data: detail,
                                      status: detail["status"] ?? "baru",
                                    ),
                                  ),
                                );

                                // hanya non-atasan yang notifnya dihapus
                                if (user.role != "atasan") {
                                  setState(() {
                                    dismissedIds.add(item["id"]);
                                  });
                                }
                              } else {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text("Data tidak ditemukan"),
                                  ),
                                );
                              }
                            },
                          ),
                        );
                      },
                    )
                  : const Center(
                      child: Text(
                        "Tidak ada notifikasi.",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 18,
                          fontFamily: "Roboto",
                          decoration: TextDecoration.none,
                        ),
                      ),
                    ),
            ),
          ],
        );
      },
    );
  }
}

Widget slideFromRightTransition(
  BuildContext context,
  Animation<double> anim1,
  Animation<double> anim2,
  Widget child,
) {
  return SlideTransition(
    position: Tween<Offset>(
      begin: const Offset(1, 0),
      end: const Offset(0, 0),
    ).animate(CurvedAnimation(parent: anim1, curve: Curves.easeOut)),
    child: child,
  );
}

/// ===== Account Panel =====
void showAccountPanel(BuildContext context) {
  final user = Provider.of<UserProvider>(context, listen: false);
  showGeneralDialog(
    context: context,
    barrierDismissible: true,
    barrierLabel: "Account Panel",
    transitionDuration: const Duration(milliseconds: 300),
    pageBuilder: (context, anim1, anim2) {
      return Align(
        alignment: Alignment.centerLeft,
        child: Material(
          color: Colors.transparent,
          child: Container(
            width: MediaQuery.of(context).size.width * 0.7,
            height: double.infinity,
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 50),
                ListTile(
                  leading: const CircleAvatar(
                    backgroundColor: Colors.blue,
                    child: Icon(Icons.person, color: Colors.white),
                  ),
                  title: Text(user.nama),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [Text(user.nip), Text("Role Anda: ${user.role}")],
                  ),
                ),
                const Divider(),
                Container(
                  decoration: const BoxDecoration(
                    border: Border(
                      bottom: BorderSide(color: Colors.grey, width: 1),
                    ),
                  ),
                  child: const ListTile(
                    leading: Icon(Icons.settings, color: Colors.blue, size: 35),
                    title: Text("Pengaturan Akun"),
                    contentPadding: EdgeInsets.symmetric(horizontal: 20),
                  ),
                ),
                Container(
                  decoration: const BoxDecoration(
                    border: Border(
                      bottom: BorderSide(color: Colors.grey, width: 1),
                    ),
                  ),
                  child: ListTile(
                    leading: const Icon(
                      Icons.logout,
                      color: Colors.red,
                      size: 35,
                    ),
                    title: const Text("Logout"),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 20),
                    onTap: () {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const LoginPage(),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
    transitionBuilder: slideFromLeftTransition,
  );
}

Widget slideFromLeftTransition(
  BuildContext context,
  Animation<double> anim1,
  Animation<double> anim2,
  Widget child,
) {
  return SlideTransition(
    position: Tween<Offset>(
      begin: const Offset(-1, 0),
      end: const Offset(0, 0),
    ).animate(CurvedAnimation(parent: anim1, curve: Curves.easeOut)),
    child: child,
  );
}
