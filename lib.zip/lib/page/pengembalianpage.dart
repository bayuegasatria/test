import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:newapp/page/dashboard.dart';
import 'package:sticky_headers/sticky_headers/widget.dart';
import '../db/database_helper.dart';

class PengembalianPage extends StatefulWidget {
  final Map<String, dynamic>? data; // 👉 data minimal (no_pengajuan dll)

  const PengembalianPage({super.key, this.data});

  @override
  State<PengembalianPage> createState() => _PengembalianPageState();
}

class _PengembalianPageState extends State<PengembalianPage> {
  final dbHelper = DatabaseHelper();
  late Future<Map<String, dynamic>?> detailFuture;

  @override
  void initState() {
    super.initState();
    final idPinjam = widget.data?["id_pinjam"];
    if (idPinjam != null) {
      detailFuture = dbHelper.getDetailPinjam(idPinjam);
    } else {
      detailFuture = Future.value(null);
    }
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case "selesai":
        return Colors.green;
      case "terlambat":
        return Colors.red;
      case "belum dimulai":
        return Colors.blue;
      default:
        return Colors.orange; // sedang dipinjam
    }
  }

  IconData _getStatusIcon(String status) {
    switch (status.toLowerCase()) {
      case "selesai":
        return Icons.check_circle;
      case "terlambat":
        return Icons.warning;
      case "belum dimulai":
        return Icons.schedule;
      default:
        return Icons.access_time;
    }
  }

  String _getStatusLabel(String status) {
    switch (status.toLowerCase()) {
      case "selesai":
        return "Selesai";
      case "terlambat":
        return "Peminjaman Terlambat";
      case "belum dimulai":
        return "Belum Dimulai";
      default:
        return "Sedang Dipinjam";
    }
  }

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat("dd MMM yyyy, HH:mm");

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        toolbarHeight: 80,
        title: const Text(
          "Detail Pengembalian",
          style: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: const Color(0xFF1E88E5),
      ),
      body: FutureBuilder<Map<String, dynamic>?>(
        future: detailFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data == null) {
            return const Center(child: Text("Data tidak ditemukan"));
          }

          final data = snapshot.data!;
          final tglMulai = DateTime.tryParse(data["tanggal_berangkat"]);
          final tglSelesai = DateTime.tryParse(data["tanggal_kembali"]);
          final now = DateTime.now();

          String status;
          if (tglMulai != null && now.isBefore(tglMulai)) {
            status = "Belum Dimulai";
          } else if (tglMulai != null &&
              tglSelesai != null &&
              (now.isAfter(tglMulai) || now.isAtSameMomentAs(tglMulai)) &&
              now.isBefore(tglSelesai)) {
            status = "Sedang Dipinjam";
          } else if (tglSelesai != null && now.isAfter(tglSelesai)) {
            status = "Terlambat";
          } else {
            status = data["status"] ?? "sedang dipinjam";
          }

          final bool isSedangDipinjam =
              status.toLowerCase() == "sedang dipinjam" ||
              status.toLowerCase() == "terlambat";

          return SingleChildScrollView(
            child: StickyHeader(
              header: Container(
                decoration: const BoxDecoration(
                  color: Colors.white,
                  border: Border(
                    bottom: BorderSide(color: Colors.blueGrey, width: 1),
                  ),
                ),
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    IconButton(
                      onPressed: () => Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const Dashboard(),
                        ),
                      ),
                      icon: const Icon(Icons.arrow_back, color: Colors.black),
                    ),
                    const SizedBox(width: 20),
                    const Text(
                      "Detail Peminjaman",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                  ],
                ),
              ),
              content: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Badge Status
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 30,
                          vertical: 12,
                        ),
                        decoration: BoxDecoration(
                          color: _getStatusColor(status),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              _getStatusIcon(status),
                              color: Colors.white,
                              size: 22,
                            ),
                            const SizedBox(width: 10),
                            Text(
                              _getStatusLabel(status),
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),

                    _buildReadOnlyField("No Pengajuan", data["no_pengajuan"]),
                    const SizedBox(height: 20),
                    _buildReadOnlyField("Nama Peminjam", data["nama"]),
                    const SizedBox(height: 20),
                    _buildReadOnlyField(
                      "Batas Waktu Pengembalian",
                      (tglSelesai != null)
                          ? dateFormat.format(tglSelesai)
                          : "-",
                    ),
                    const SizedBox(height: 20),
                    _buildReadOnlyField("Tujuan", data["tujuan"]),
                    const SizedBox(height: 20),
                    _buildReadOnlyField("Nama Kendaraan", data["kendaraan"]),
                    const SizedBox(height: 30),

                    if (isSedangDipinjam)
                      Center(
                        child: SizedBox(
                          height: 60,
                          width: 200,
                          child: ElevatedButton(
                            onPressed: () async {
                              final idPinjam =
                                  data["id"]; // ambil dari Map data
                              await dbHelper.updateStatusPinjam(
                                idPinjam,
                                "selesai",
                              );

                              if (context.mounted) {
                                Navigator.pop(context, "Selesai");
                              }
                            },

                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            child: const Text(
                              "Selesai Pinjam",
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                              ),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildReadOnlyField(String label, String? value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
        ),
        const SizedBox(height: 10),
        TextField(
          readOnly: true,
          controller: TextEditingController(text: value ?? "-"),
          decoration: const InputDecoration(border: OutlineInputBorder()),
        ),
      ],
    );
  }
}
