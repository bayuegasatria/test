import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:newapp/page/dashboard.dart';
import 'package:newapp/page/detailpinjampage.dart';
import 'package:newapp/page/user_provider.dart';
import 'package:newapp/db/database_helper.dart';
import 'package:provider/provider.dart';
import 'package:sticky_headers/sticky_headers/widget.dart';

class HistoryPinjamPage extends StatefulWidget {
  const HistoryPinjamPage({super.key});

  @override
  State<HistoryPinjamPage> createState() => _HistoryPinjamPageState();
}

class _HistoryPinjamPageState extends State<HistoryPinjamPage> {
  final DatabaseHelper dbHelper = DatabaseHelper();
  late Future<List<Map<String, dynamic>>> futureHistory;
  final DateFormat dateFormat = DateFormat("dd MMM yyyy, HH:mm");

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  void _loadHistory() {
    final user = Provider.of<UserProvider>(context, listen: false);
    final int currentUserId = int.tryParse(user.id) ?? 0;

    setState(() {
      futureHistory = dbHelper.getHistoryPinjam(
        userId: currentUserId,
        role: user.role,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Text(
          "History Peminjaman",
          style: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: const Color(0xFF1E88E5),
      ),
      body: SingleChildScrollView(
        child: StickyHeader(
          header: Container(
            decoration: const BoxDecoration(
              color: Colors.white,
              border: Border(
                bottom: BorderSide(color: Colors.blueGrey, width: 1),
              ),
            ),
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                IconButton(
                  onPressed: () => Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => const Dashboard()),
                  ),
                  icon: const Icon(Icons.arrow_back, color: Colors.black),
                ),
                const SizedBox(width: 20),
                const Text(
                  "History Peminjaman",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                ),
              ],
            ),
          ),
          content: FutureBuilder<List<Map<String, dynamic>>>(
            future: futureHistory,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(
                  child: Padding(
                    padding: EdgeInsets.all(20),
                    child: CircularProgressIndicator(),
                  ),
                );
              }

              if (!snapshot.hasData || snapshot.data!.isEmpty) {
                return const Center(
                  child: Padding(
                    padding: EdgeInsets.all(20),
                    child: Text(
                      "Tidak ada history peminjaman.",
                      style: TextStyle(fontSize: 16, color: Colors.black54),
                    ),
                  ),
                );
              }

              final selesaiHistory = snapshot.data!;
              return ListView.builder(
                itemCount: selesaiHistory.length,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemBuilder: (context, index) {
                  final item = selesaiHistory[index];

                  return Card(
                    color: Colors.white,
                    margin: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 6,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: ListTile(
                      contentPadding: const EdgeInsets.all(12),
                      title: Text(
                        item["no_pengajuan"],
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Nama Peminjam: ${item["nama_user"]}"),
                          Text("Mobil: ${item["nama_kendaraan"]}"),
                          Text("Tujuan: ${item["tujuan"]}"),
                          Text(
                            "Tanggal Pengembalian: ${dateFormat.format(DateTime.parse(item["tanggal_pengembalian"]))}",
                          ),
                        ],
                      ),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => Detailpinjampage(
                              data: {
                                "no_pengajuan": item["no_pengajuan"],
                                "nama": item["nama_user"],
                                "batas_pengembalian":
                                    item["tanggal_pengembalian"],
                                "tujuan": item["tujuan"],
                                "kendaraan": item["nama_kendaraan"],
                                "status": item["status"],
                              },
                            ),
                          ),
                        );
                      },
                    ),
                  );
                },
              );
            },
          ),
        ),
      ),
    );
  }
}
